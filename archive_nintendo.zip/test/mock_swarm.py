#!/usr/bin/env python3
"""Локальный стенд: HTTP- и UDP-трекер + 2 сида. Создаёт тестовые торренты.
Использование: mock_swarm.py <outdir> [bad]"""
import hashlib, os, socket, struct, sys, threading, random, http.server, socketserver, time

out = sys.argv[1]
bad = len(sys.argv) > 2 and sys.argv[2] == "bad"
random.seed(7)
os.makedirs(out + "/payload/mocktest/a", exist_ok=True)
os.makedirs(out + "/payload/mocktest/c/d", exist_ok=True)
os.makedirs(out + "/torrents", exist_ok=True)

def rnd(n): return bytes(random.getrandbits(8) for _ in range(n))
files = [("a/one.bin", rnd(3300000)), ("b_empty.txt", b""), ("b/two.bin", rnd(1000000)), ("c/d/three.bin", rnd(500001))]
for rel, data in files:
    p = out + "/payload/mocktest/" + rel
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "wb").write(data)
single = rnd(777777)
open(out + "/payload/single.bin", "wb").write(single)

def benc(v):
    if isinstance(v, int): return b"i%de" % v
    if isinstance(v, bytes): return b"%d:" % len(v) + v
    if isinstance(v, str): return benc(v.encode())
    if isinstance(v, list): return b"l" + b"".join(benc(x) for x in v) + b"e"
    if isinstance(v, dict): return b"d" + b"".join(benc(k) + benc(v[k]) for k in sorted(v)) + b"e"
    raise TypeError

PL = 262144
def mk_info(name, flist):
    blob = b"".join(d for _, d in flist)
    hashes = b"".join(hashlib.sha1(blob[i:i + PL]).digest() for i in range(0, len(blob), PL))
    info = {"name": name, "piece length": PL, "pieces": hashes}
    if len(flist) == 1 and flist[0][0] is None: info["length"] = len(blob)
    else: info["files"] = [{"length": len(d), "path": r.split("/")} for r, d in flist]
    return info, blob

info_a, blob_a = mk_info("mocktest", files)
info_b, blob_b = mk_info("single.bin", [(None, single)])
blobs = {hashlib.sha1(benc(info_a)).digest(): blob_a, hashlib.sha1(benc(info_b)).digest(): blob_b}
infos = {hashlib.sha1(benc(info_a)).digest(): info_a, hashlib.sha1(benc(info_b)).digest(): info_b}

# ── сиды
corrupted = set()
def seeder(sock):
    while True:
        c, _ = sock.accept()
        threading.Thread(target=serve, args=(c,), daemon=True).start()

def recvn(c, n):
    b = b""
    while len(b) < n:
        x = c.recv(n - len(b))
        if not x: raise EOFError
        b += x
    return b

def serve(c):
    try:
        hs = recvn(c, 68)
        ih = hs[28:48]
        if ih not in blobs: c.close(); return
        blob = blobs[ih]; npieces = (len(blob) + PL - 1) // PL
        c.sendall(bytes([19]) + b"BitTorrent protocol" + bytes(8) + ih + b"-MOCK00-123456789012")
        bf = bytearray((npieces + 7) // 8)
        for i in range(npieces): bf[i >> 3] |= 0x80 >> (i & 7)
        c.sendall(struct.pack(">IB", 1 + len(bf), 5) + bytes(bf))
        while True:
            ln = struct.unpack(">I", recvn(c, 4))[0]
            if ln == 0: continue
            m = recvn(c, ln)
            if m[0] == 2: c.sendall(struct.pack(">IB", 1, 1))
            elif m[0] == 6:
                idx, beg, l = struct.unpack(">III", m[1:13])
                d = bytearray(blob[idx * PL + beg: idx * PL + beg + l])
                if bad and idx == 3 and beg == 0 and "x" not in corrupted and ih == list(blobs)[0]:
                    corrupted.add("x"); d[5] ^= 0xFF
                c.sendall(struct.pack(">IBII", 9 + len(d), 7, idx, beg) + bytes(d))
                time.sleep(0.001)
    except Exception:
        try: c.close()
        except Exception: pass

ports = []
for _ in range(2):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); s.listen(16)
    ports.append(s.getsockname()[1])
    threading.Thread(target=seeder, args=(s,), daemon=True).start()
peers = b"".join(socket.inet_aton("127.0.0.1") + struct.pack(">H", p) for p in ports)

class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = benc({"interval": 60, "peers": peers})
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
hport = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()

class U(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        if len(data) >= 16 and struct.unpack(">Q", data[:8])[0] == 0x41727101980 and struct.unpack(">I", data[8:12])[0] == 0:
            sock.sendto(struct.pack(">II", 0, struct.unpack(">I", data[12:16])[0]) + b"CONNID12", self.client_address)
        elif len(data) >= 98 and struct.unpack(">I", data[8:12])[0] == 1:
            sock.sendto(struct.pack(">IIIII", 1, struct.unpack(">I", data[12:16])[0], 60, 0, 2) + peers, self.client_address)
udp = socketserver.ThreadingUDPServer(("127.0.0.1", 0), U)
uport = udp.server_address[1]
threading.Thread(target=udp.serve_forever, daemon=True).start()

def write_torrent(fn, info, announce, alist=None):
    t = {"announce": announce, "info": info}
    if alist: t["announce-list"] = alist
    open(out + "/torrents/" + fn, "wb").write(benc(t))
write_torrent("a_mocktest.torrent", info_a, "http://127.0.0.1:%d/announce" % hport)
write_torrent("b_single.torrent", info_b, "udp://127.0.0.1:%d" % uport, [["https://nope.invalid/announce"], ["udp://127.0.0.1:%d" % uport]])
print("READY", flush=True)
while True: time.sleep(1)
