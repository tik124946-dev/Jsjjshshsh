// Тест логики установщика NSP на заглушке бэкенда: ./nsp_test
#include "../source/nsp_install.hpp"
#include "../source/util.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <map>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

struct Mock : NspBackend {
    std::map<std::string, std::vector<uint8_t>> store;     // зарегистрированный контент
    std::vector<uint8_t> ph; std::string ph_id; bool ph_open = false;
    std::vector<uint8_t> cnmt; int tik = 0; std::vector<uint8_t> rec; uint64_t rec_app = 0, meta_id = 0; int commits = 0, pushes = 0;
    int deleted = 0, aborted = 0; bool preexisting = false;
    bool open(std::string&) override { return true; }
    int begin_content(const uint8_t cid[16], uint64_t size, std::string&) override {
        std::string h = to_hex(cid, 16);
        if (preexisting && h[0] == '1') return 1;
        ph.assign(size, 0); ph_id = h; ph_open = true; return 0;
    }
    bool write_content(uint64_t off, const uint8_t* p, size_t n, std::string& e) override {
        if (!ph_open || off + n > ph.size()) { e = "bad write"; return false; }
        memcpy(ph.data() + off, p, n); return true;
    }
    bool end_content(const uint8_t*, std::string&) override { store[ph_id] = ph; ph_open = false; return true; }
    void abort_content() override { ph_open = false; aborted++; }
    void delete_content(const uint8_t cid[16]) override { store.erase(to_hex(cid, 16)); deleted++; }
    bool read_cnmt(const uint8_t*, std::vector<uint8_t>& out, std::string&) override { out = cnmt; return true; }
    bool import_ticket(const std::vector<uint8_t>& t, const std::vector<uint8_t>& c, std::string&) override { if (!t.empty() && !c.empty()) tik++; return true; }
    bool set_meta(uint64_t id, uint32_t, uint8_t, const std::vector<uint8_t>& r, std::string&) override { meta_id = id; rec = r; return true; }
    bool commit_meta(std::string&) override { commits++; return true; }
    bool push_record(uint64_t app, uint64_t, uint32_t, uint8_t, std::string&) override { rec_app = app; pushes++; return true; }
};

static void p32(std::vector<uint8_t>& v, uint32_t x) { for (int i = 0; i < 4; i++) v.push_back(x >> (8 * i)); }
static void p64(std::vector<uint8_t>& v, uint64_t x) { for (int i = 0; i < 8; i++) v.push_back(x >> (8 * i)); }

static std::vector<uint8_t> rnd(size_t n) { std::vector<uint8_t> v(n); for (auto& b : v) b = rand(); return v; }

static std::vector<uint8_t> make_nsp(const std::vector<std::pair<std::string, std::vector<uint8_t>>>& files) {
    std::string strtab; std::vector<uint32_t> so;
    for (auto& f : files) { so.push_back((uint32_t)strtab.size()); strtab += f.first; strtab.push_back(0); }
    while (strtab.size() % 16) strtab.push_back(0);
    std::vector<uint8_t> h; h.insert(h.end(), {'P', 'F', 'S', '0'});
    p32(h, (uint32_t)files.size()); p32(h, (uint32_t)strtab.size()); p32(h, 0);
    uint64_t off = 0;
    for (size_t i = 0; i < files.size(); i++) { p64(h, off); p64(h, files[i].second.size()); p32(h, so[i]); p32(h, 0); off += files[i].second.size(); }
    h.insert(h.end(), strtab.begin(), strtab.end());
    for (auto& f : files) h.insert(h.end(), f.second.begin(), f.second.end());
    return h;
}

static std::vector<uint8_t> make_cnmt(uint64_t tid, uint8_t type, const std::vector<std::string>& cids) {
    std::vector<uint8_t> c; p64(c, tid); p32(c, 0x10000); c.push_back(type); c.push_back(0);
    uint16_t ext = 0x10; c.push_back(ext); c.push_back(0);
    c.push_back((uint8_t)cids.size()); c.push_back(0); c.push_back(0); c.push_back(0);  // content_count, meta_count
    c.push_back(0); c.insert(c.end(), 3, 0); p32(c, 0); p32(c, 0);
    p64(c, 0xAAAAAAAAAAAAAAAAull); p32(c, 0x5000); p32(c, 0);            // ext header (patch_id, sysver, ...)
    for (auto& s : cids) {
        c.insert(c.end(), 32, 0x11);                                      // sha256
        uint8_t id[16]; from_hex(s, id, 16); c.insert(c.end(), id, id + 16);
        p32(c, 1234); c.push_back(0); c.push_back(0); c.push_back(1); c.push_back(0);
    }
    c.insert(c.end(), 32, 0x22);                                          // digest
    return c;
}

int main() {
    srand(5);
    std::string c1 = "1111111111111111aaaaaaaaaaaaaaaa", c2 = "2222222222222222bbbbbbbbbbbbbbbb", cm = "33333333333333330123456789abcdef";
    auto n1 = rnd(300000), n2 = rnd(70000), nm = rnd(2048);
    uint64_t tid = 0x0100AAAABBBB0000ull;
    auto nsp = make_nsp({{c1 + ".nca", n1}, {c2 + ".nca", n2}, {cm + ".cnmt.nca", nm}, {"0100aaaa0000.tik", rnd(0x2C0)}, {"0100aaaa0000.cert", rnd(0x700)}, {"readme.txt", rnd(10)}});
    // 1) обычная установка, случайные размеры порций
    {
        Mock* mk = new Mock; mk->cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(mk);
        size_t pos = 0;
        while (pos < nsp.size()) { size_t k = 1 + rand() % 9000; if (pos + k > nsp.size()) k = nsp.size() - pos; CHECK(ins.write(nsp.data() + pos, k)); pos += k; }
        CHECK(ins.finish());
        CHECK(mk->store.size() == 3);
        CHECK(mk->store[c1] == n1 && mk->store[c2] == n2 && mk->store[cm] == nm);
        CHECK(mk->tik == 1 && mk->commits == 1 && mk->pushes == 1);
        CHECK(mk->rec_app == tid && mk->meta_id == tid);
        // 8 заголовок + 0x10 ext + 3*0x18 инфо
        CHECK(mk->rec.size() == 8 + 0x10 + 3 * 0x18);
        CHECK(mk->rec[2] == 3);                       // content_count = 2 + CNMT
        CHECK(memcmp(mk->rec.data() + 8 + 0x10, "\x33\x33\x33\x33\x33\x33\x33\x33\x01\x23\x45\x67\x89\xab\xcd\xef", 16) == 0);
        CHECK(mk->rec[8 + 0x10 + 20] == 0 && mk->rec[8 + 0x10 + 22] == 0);   // тип Meta
        printf("info=%s\n", ins.info().c_str());
    }
    // 2) в NSP не хватает NCA
    {
        Mock* mk = new Mock; mk->cnmt = make_cnmt(tid, 0x80, {c1, c2, "99999999999999999999999999999999"});
        NspInstaller ins(mk);
        CHECK(ins.write(nsp.data(), nsp.size()));
        CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
        ins.abort();
        CHECK(mk->store.empty());                     // откат всё удалил
    }
    // 3) обрезанный NSP
    {
        Mock* mk = new Mock; mk->cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(mk);
        CHECK(ins.write(nsp.data(), nsp.size() - 3000));
        CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
    }
    // 4) контент уже установлен — данные пропускаем
    {
        Mock* mk = new Mock; mk->preexisting = true; mk->cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(mk);
        CHECK(ins.write(nsp.data(), nsp.size()));
        CHECK(ins.finish());
        CHECK(mk->store.count(c1) == 0 && mk->store.count(c2) == 1);
    }
    // 5) системный тип и мусор вместо NSP
    {
        Mock* mk = new Mock; mk->cnmt = make_cnmt(tid, 0x01, {c1, c2});
        NspInstaller ins(mk);
        CHECK(ins.write(nsp.data(), nsp.size())); CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
        Mock* mk2 = new Mock; NspInstaller ins2(mk2);
        uint8_t junk[64] = {1, 2, 3}; CHECK(!ins2.write(junk, sizeof junk));
        printf("ожидаемая ошибка: %s\n", ins2.error().c_str());
    }
    // 6) патч/DLC: app id берётся из расширенного заголовка
    {
        Mock* mk = new Mock; mk->cnmt = make_cnmt(tid + 0x800, 0x81, {c1, c2});
        NspInstaller ins(mk);
        CHECK(ins.write(nsp.data(), nsp.size())); CHECK(ins.finish());
        CHECK(mk->rec_app == 0xAAAAAAAAAAAAAAAAull);
    }
    printf(fails ? "НЕУДАЧА (%d)\n" : "ВСЕ ТЕСТЫ NSP ПРОШЛИ\n", fails);
    return fails != 0;
}
