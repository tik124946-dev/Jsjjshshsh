#pragma once
#include <stdint.h>
#include <string>

// Установщик NSP: данные подаются потоком, на карте памяти не лежит ничего лишнего.
struct Installer {
    virtual ~Installer() {}
    virtual bool write(const uint8_t* p, size_t n) = 0;
    virtual bool finish() = 0;            // регистрация в базе (ncm/ns/es)
    virtual void abort() = 0;             // откат: удаляем недоустановленное
    virtual std::string error() = 0;
    virtual std::string info() = 0;       // что ставится (ID игры и т. д.)
};

// Всё, что зависит от железа. На Switch — libnx, на хосте — заглушка для тестов.
struct Platform {
    virtual ~Platform() {}
    virtual std::string root() = 0;                       // "sdmc:/"
    virtual std::string time_str() = 0;                   // "14:05"
    virtual int64_t epoch() = 0;                          // секунды (локальное время устройства)
    virtual std::string date_str(int64_t epoch) = 0;      // "23.11.26"
    virtual int64_t free_space(int storage) = 0;          // 0 — SD, 1 — память консоли; -1 если неизвестно
    virtual int64_t total_space(int storage) = 0;
    virtual bool can_install() = 0;                       // доступна ли установка NSP (ncm/ns/es)
    virtual Installer* new_installer(int storage) = 0;    // storage: 0 SD, 1 NAND
    virtual void keep_awake(bool on) = 0;                 // запретить сон/затемнение
    virtual void backlight(bool on) = 0;                  // подсветка экрана
};
