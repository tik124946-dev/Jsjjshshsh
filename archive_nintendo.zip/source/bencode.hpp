#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include <utility>

// Разбор bencode. Для словарей запоминаем байтовый диапазон [b,e) — нужен для info_hash.
struct BVal {
    enum T { NONE, INT, STR, LIST, DICT } t = NONE;
    int64_t i = 0;
    std::string s;
    std::vector<BVal> l;
    std::vector<std::pair<std::string, BVal>> d;
    size_t b = 0, e = 0;

    const BVal* get(const char* k) const {
        for (auto& kv : d) if (kv.first == k) return &kv.second;
        return nullptr;
    }
};

inline bool bdecode(const uint8_t* p, size_t n, size_t& pos, BVal& out, int depth = 0) {
    if (depth > 32 || pos >= n) return false;
    out.b = pos;
    uint8_t c = p[pos];
    if (c == 'i') {
        pos++;
        bool neg = false;
        if (pos < n && p[pos] == '-') { neg = true; pos++; }
        int64_t v = 0; int digits = 0;
        while (pos < n && p[pos] >= '0' && p[pos] <= '9') {
            if (digits++ > 18) return false;
            v = v * 10 + (p[pos++] - '0');
        }
        if (!digits || pos >= n || p[pos] != 'e') return false;
        pos++;
        out.t = BVal::INT; out.i = neg ? -v : v;
    } else if (c >= '0' && c <= '9') {
        uint64_t len = 0; int digits = 0;
        while (pos < n && p[pos] >= '0' && p[pos] <= '9') {
            if (digits++ > 10) return false;
            len = len * 10 + (p[pos++] - '0');
        }
        if (pos >= n || p[pos] != ':') return false;
        pos++;
        if (len > n - pos) return false;
        out.t = BVal::STR; out.s.assign((const char*)p + pos, (size_t)len);
        pos += (size_t)len;
    } else if (c == 'l') {
        pos++;
        out.t = BVal::LIST;
        while (pos < n && p[pos] != 'e') {
            out.l.emplace_back();
            if (!bdecode(p, n, pos, out.l.back(), depth + 1)) return false;
        }
        if (pos >= n) return false;
        pos++;
    } else if (c == 'd') {
        pos++;
        out.t = BVal::DICT;
        while (pos < n && p[pos] != 'e') {
            BVal k;
            if (!bdecode(p, n, pos, k, depth + 1) || k.t != BVal::STR) return false;
            BVal v;
            if (!bdecode(p, n, pos, v, depth + 1)) return false;
            out.d.emplace_back(k.s, std::move(v));
        }
        if (pos >= n) return false;
        pos++;
    } else return false;
    out.e = pos;
    return true;
}
