#pragma once
#include <stdint.h>
#include <string>
#include <vector>

uint64_t now_ms();                                   // монотонные миллисекунды
bool mkdirs(const std::string& path);                // mkdir -p
bool read_file(const std::string& path, std::vector<uint8_t>& out, size_t max = 64u << 20);
bool write_file(const std::string& path, const std::string& data);
bool list_dir(const std::string& path, std::vector<std::string>& names);
bool file_exists(const std::string& path);
std::string human_size(double bytes);                // "1.5 ГБ"
std::string human_speed(double bps);                 // "3.2 МБ/с"
std::string human_time(int64_t sec);                 // "1 ч 05 мин"
std::string to_hex(const uint8_t* p, size_t n);
bool from_hex(const std::string& s, uint8_t* out, size_t n);
bool ends_with_ci(const std::string& s, const char* suf);
std::string lower(std::string s);
