#pragma once
#include "platform.hpp"
#include "pfs.hpp"
#include <vector>
#include <set>
#include <string>

// Всё, что требует системных сервисов (ncm / ns / es). Реализация на Switch — ncm_backend.cpp.
struct NspBackend {
    virtual ~NspBackend() {}
    virtual bool open(std::string& err) = 0;
    // 0 — создан placeholder, 1 — такой контент уже установлен (данные пропускаем), <0 — ошибка
    virtual int begin_content(const uint8_t cid[16], uint64_t size, std::string& err) = 0;
    virtual bool write_content(uint64_t off, const uint8_t* p, size_t n, std::string& err) = 0;
    virtual bool end_content(const uint8_t cid[16], std::string& err) = 0;      // placeholder → зарегистрированный NCA
    virtual void abort_content() = 0;                                          // удалить текущий placeholder
    virtual void delete_content(const uint8_t cid[16]) = 0;                    // откат уже зарегистрированного
    virtual bool read_cnmt(const uint8_t cid[16], std::vector<uint8_t>& out, std::string& err) = 0;
    virtual bool import_ticket(const std::vector<uint8_t>& tik, const std::vector<uint8_t>& cert, std::string& err) = 0;
    virtual bool set_meta(uint64_t id, uint32_t ver, uint8_t type, const std::vector<uint8_t>& rec, std::string& err) = 0;
    virtual bool commit_meta(std::string& err) = 0;
    virtual bool push_record(uint64_t app_id, uint64_t id, uint32_t ver, uint8_t type, std::string& err) = 0;
};

class NspInstaller : public Installer, private PfsHandler {
public:
    explicit NspInstaller(NspBackend* be);
    ~NspInstaller() override;
    bool write(const uint8_t* p, size_t n) override;
    bool finish() override;
    void abort() override;
    std::string error() override { return err_; }
    std::string info() override { return info_; }
    uint64_t written() const { return total_in_; }

private:
    enum Kind { K_OTHER, K_NCA, K_CNMT, K_TIK, K_CERT };
    struct Meta { uint8_t cid[16]; uint64_t size; };
    struct Created { uint8_t cid[16]; };
    NspBackend* be_;
    PfsStream pfs_;
    std::string err_, info_;
    bool opened_ = false, done_ = false;
    uint64_t total_in_ = 0;
    // текущий файл
    Kind kind_ = K_OTHER;
    uint8_t cur_cid_[16];
    uint64_t cur_size_ = 0, cur_off_ = 0;
    bool cur_skip_ = false, cur_open_ = false;
    std::string cur_name_;
    std::vector<uint8_t> cur_buf_;
    // накопленное
    std::vector<Meta> metas_;
    std::vector<Created> created_;
    std::set<std::string> seen_;                                   // hex content-id всех NCA в этом NSP
    std::vector<std::pair<std::string, std::vector<uint8_t>>> tiks_, certs_;

    bool pfs_begin(const std::string& name, uint64_t size) override;
    bool pfs_data(const uint8_t* p, size_t n) override;
    bool pfs_end() override;
    bool fail(const std::string& e) { if (err_.empty()) err_ = e; return false; }
    bool register_all();
};

// разбор записи CNMT → готовая запись для ncm (экспортируем для тестов)
bool build_meta_record(const std::vector<uint8_t>& cnmt, const uint8_t meta_cid[16], uint64_t meta_size,
                       uint64_t& id, uint32_t& ver, uint8_t& type, uint64_t& app_id,
                       std::vector<uint8_t>& record, std::vector<std::string>& content_ids, std::string& err);
