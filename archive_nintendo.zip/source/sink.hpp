#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string>

struct Meta;

// Потребитель данных торрента. Данные приходят строго по порядку файлов.
struct Sink {
    virtual ~Sink() {}
    virtual bool file_begin(const Meta& m, size_t idx) = 0;
    virtual bool file_data(const uint8_t* p, size_t n) = 0;
    virtual bool file_end() = 0;
    virtual std::string error() = 0;
};
